import http.server, socketserver, threading, webbrowser
from pathlib import Path
import os
os.chdir(Path(__file__).resolve().parent)
class Handler(http.server.SimpleHTTPRequestHandler):
    def do_GET(self):
        if self.path == '/rounds': self.path = '/rounds.html'
        return super().do_GET()
with socketserver.TCPServer(('127.0.0.1', 0), Handler) as server:
    url = 'http://127.0.0.1:%s/' % server.server_address[1]
    print('Iron Dominion preview:', url, flush=True)
    print('Keep this window open while using the preview. Press Ctrl+C to stop.', flush=True)
    threading.Timer(0.5, lambda: webbrowser.open(url)).start()
    server.serve_forever()
