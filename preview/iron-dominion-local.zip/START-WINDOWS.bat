@echo off
py -3 start.py
pause
